package tn.esprit.tpfoyer.entity;

public enum TypeChambre {
    SIMPLE , DOUBLE, TRIPLE
}
